Upgrading
============

To upgrade from mPDF 5.6 to 5.6.1, simply upload the 2 files to their corresponding folders, overwriting files as required.




