<?php
return array(
	'basePath' => dirname(__FILE__) . DIRECTORY_SEPARATOR . '..',
	'name' => 'My Web Application',
	'sourceLanguage'	=>	'en',
	'language' => 'en',
	// preloading 'log' component
	'preload' => array(
		'log',
		'cache',
		'setting',
		'translate'
	) ,
	// autoloading model and component classes
	'import' => array(
		// Rights
		'application.modules.rights.components.*',
		'application.modules.rights.models.*',
		// Yii-user
		'application.modules.user.components.*',
		'application.modules.user.models.*',
		// Core
		'application.modules.core.components.*',
		'application.modules.core.models.*',
		// Main Application models and components
		'application.models.*',
		'application.components.*',
		// Extension Main Components
		'ext.components.*',
		'ext.helpers.*',
		'ext.gtc.components.*',
        // SwiftMailer
		'ext.mail.YiiMailMessage',
		// Image
		"ext.image.*",
		// Translate
		'application.modules.translate.TranslateModule'
	) ,
	'modules' => array(
		'user',
		'rights' => array(
			'superuserName' => 'Admin', // Name of the role with super user privileges.
			'authenticatedName' => 'Authenticated', // Name of the authenticated user role.
			'userClass' => 'User', // Name of the User model class.
			'userIdColumn' => 'id', // Name of the user id column in the database.
			'userNameColumn' => 'username', // Name of the user name column in the database.
			'enableBizRule' => true, // Whether to enable authorization item business rules.
			'enableBizRuleData' => false, // Whether to enable data for business rules.
			'flashSuccessKey' => 'RightsSuccess', // Key to use for setting success flash messages.
			'flashErrorKey' => 'RightsError', // Key to use for setting error flash messages.
			'appLayout' => 'application.views.layouts.column2', // Layout to use for displaying Rights.
			'baseUrl' => '/rights', // Base URL for Rights. Change if module is nested.
			'cssFile' => 'rights.css', // Style sheet file to use for Rights.
		) ,
		'core',
		'contents',
		'translate'
	) ,
	// application components
	'components' => array(
		'request' => array(
			'enableCsrfValidation' => FALSE,
		) ,
		'input' => array(
			'class' => 'ext.components.Input',
			'cleanPost' => true,
			'cleanGet' => true,
		) ,
		'cache' => array(
			'class' => 'system.caching.CDummyCache',
		) ,
		'user' => array(
			'class' => 'RWebUser',
			'allowAutoLogin' => true,
			'loginUrl' => array(
				'/user/login'
			) ,
		) ,
		'urlManager' => array(
			'urlFormat'=>'path',
			'rules'=>array(
				'<controller:\w+>/<id:\d+>'=>'<controller>/view',
				'<controller:\w+>/<action:\w+>/<id:\d+>'=>'<controller>/<action>',
				'<controller:\w+>/<action:\w+>'=>'<controller>/<action>',
			),
		) ,
		'db' => array(
			'connectionString' => 'sqlite:' . dirname(__FILE__) . '/../data/yiicorecms.db',
			'emulatePrepare' => true,
			'username' => 'webdvvt',
			'password' => 'LYh4EWVbu8WYmSKr',
			'charset' => 'utf8',
			'tablePrefix' => '',
			'enableParamLogging' => TRUE,
			'enableProfiling' => TRUE
		) ,
		'authManager' => array(
			'class' => 'RDbAuthManager',
			'connectionID' => 'db',
			'assignmentTable' => 'authassignment',
			'itemChildTable'	=>	'authitemchild',
			'itemTable'	=>	'authitem',
			'rightsTable'	=>	'rights',
		) ,
		'errorHandler' => array(
			// use 'site/error' action to display errors
			'errorAction' => 'site/error',
		) ,
		'log' => array(
			'class' => 'CLogRouter',
			'routes' => array(
				array(
					'class' => 'CFileLogRoute',
					'levels' => 'error, warning',
				) ,
			),
		) ,
		'setting' => array(
			'class' => 'ext.components.Settings',
		) ,
		'file' => array(
			'class' => 'ext.components.CFile',
		) ,
		'dbmessages' => array(
			'class'	=>	'CDbMessageSource',
			'sourceMessageTable'	=>	'sourcemessage',
			'translatedMessageTable'	=>	'message',
			'language'	=>	'en',
			'onMissingTranslation'	=> array('TranslateModule', 'missingTranslation'),
		),
		'translate'=>array(//if you name your component something else change TranslateModule
            'class'=>'translate.components.MPTranslate',
//any avaliable options here
            'acceptedLanguages'=>array(
                  'en'=>'English',
                  'vi'=>'Vietnamese',
			),
			'autoTranslate'	=> FALSE,
		),
		'mail' => array(
			'class' => 'ext.mail.YiiMail',
			'transportType' => 'php', 		//Can be either 'php' or 'smtp'
			'viewPath' => 'application.views.mail',
/*			'transportOptions' => array(	//See the SwiftMailer documentaion for the option meanings
				'host'	=>	NULL,
				'username' => NULL,
				'password'	=> NULL,
				'port'	=>	NULL,
				'encryption'	=>	NULL,
				'timeout'	=> NULL,
				'extensionHandlers'	=>	NULL,
			),
*/
			'logging' => true,
			'dryRun' => TRUE
		),
	) ,
	// application-level parameters that can be accessed
	// using Yii::app()->params['paramName']
	'params' => array(
		// this is used in contact page
		'adminEmail' => 'webmaster@example.com',
	) ,
);
