<?php
/**
 * Configuration for Dev1
 */
return CMap::mergeArray(require (dirname(__FILE__) . DIRECTORY_SEPARATOR . 'webapp.php') , array(
	'preload'	=>	array('log',
		'lang',
		'cache',
		'setting',
		//'shoppingCart'
	),
	'import' => array(
		'ext.yiidebugtb.*',
		'ext.gtc.components.*',
		'application.modules.core.models.*',
		'application.modules.shop.models.*',
		'ext.yiiext.components.shoppingCart.*'
	) ,
	'modules' => array(
		'gii' => array(
			'class' => 'system.gii.GiiModule',
			'password' => 'myroot',
			'ipFilters' => array(
			) ,
			'generatorPaths' => array(
				'ext.gtc',
			)
		) ,
		'node',
		'shop',
		'contents',
	) ,
	'components' => array(
		'db' => array(
			'connectionString' => 'mysql:host=localhost;unix_socket=/var/lib/mysql/mysql.sock;port=3306;dbname=yii_bbbart',
			'emulatePrepare' => true,
			'username' => 'root',
			'password' => 'myroot',
			'charset' => 'utf8',
			'tablePrefix' => '',
			'enableParamLogging' => TRUE,
			'enableProfiling' => TRUE
		) ,
		// Remove me in production mode.
		'cache' => array(
			'class' => 'system.caching.CDummyCache',
		) ,
		// Remove me in production mode.
		'log' => array(
			'class' => 'CLogRouter',
			'routes' => array(
				array(
					'class' => 'ext.yiidebugtb.XWebDebugRouter',
					'config' => 'alignRight, yamlStyle',
					'levels' => 'error, warning, trace, profile, info',
				) ,
				array(
					'class' => 'CFileLogRoute',
					'levels' => 'error, warning, info',
				) ,
			) ,
		) ,
		'shoppingCart' => array(
	        'class' => 'ext.yiiext.components.shoppingCart.EShoppingCart',
	    ),
	) ,
));
