<?php
/**
 * Configuration for Dev1
 */
return CMap::mergeArray(require (dirname(__FILE__) . DIRECTORY_SEPARATOR . 'webapp.php') , array(
	'name' => 'GTel Internet',
	'import' => array(
		'ext.yiidebugtb.*',
		'ext.gtc.components.*',
		'application.modules.core.models.*',
		'application.modules.shop.models.*',
		'ext.yiiext.components.shoppingCart.*'
	) ,
	'modules' => array(
		'gii' => array(
			'class' => 'system.gii.GiiModule',
			'password' => 'myroot',
			'ipFilters' => array(
			) ,
			'generatorPaths' => array(
				'ext.gtc',
			)
		) ,
		'node',
	) ,
	'components' => array(
		'db' => array(
			'connectionString' => 'mysql:host=localhost;unix_socket=/var/lib/mysql/mysql.sock;port=3306;dbname=gtelportal',
			'emulatePrepare' => true,
			'username' => 'webdvvt',
			'password' => 'LYh4EWVbu8WYmSKr',
			'charset' => 'utf8',
			'tablePrefix' => '',
			'enableParamLogging' => TRUE,
			'enableProfiling' => TRUE
		) ,
		// Remove me in production mode.
		'cache' => array(
			'class' => 'system.caching.CDummyCache',
		) ,
		// Remove me in production mode.
		'log' => array(
			'class' => 'CLogRouter',
			'routes' => array(
				array(
					'class' => 'ext.yiidebugtb.XWebDebugRouter',
					'config' => 'alignRight, yamlStyle',
					'levels' => 'error, warning, trace, profile, info',
				) ,
				array(
					'class' => 'CFileLogRoute',
					'levels' => 'error, warning, info',
				) ,
			) ,
		) ,
	) ,
));
