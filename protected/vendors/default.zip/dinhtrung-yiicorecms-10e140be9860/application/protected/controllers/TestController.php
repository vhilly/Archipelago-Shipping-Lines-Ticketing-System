<?php
/**
 * TestController  class file.
 *
 */

/**
 * TestController is a class for...
 *
 *
 */

class TestController extends Controller
{
	public function actionBrowse()
	{
		$this->render('browse');
	}

	public function actionCreate()
	{
		$this->render('create');
	}

	public function actionDelete()
	{
		$this->render('delete');
	}

	public function actionDisplay()
	{
		$this->render('display');
	}

	public function actionExport()
	{
		$this->render('export');
	}

	public function actionGet()
	{
		$this->render('get');
	}

	public function actionImport()
	{
		$this->render('import');
	}

	public function actionIndex()
	{
		$this->render('index');
	}

	public function actionItem()
	{
		$this->render('item');
	}

	public function actionUpdate()
	{
		$this->render('update');
	}

	public function actionView()
	{
		$this->render('view');
	}

	// Uncomment the following methods and override them if needed
	/*
	public function filters()
	{
		// return the filter configuration for this controller, e.g.:
		return array(
			'inlineFilterName',
			array(
				'class'=>'path.to.FilterClass',
				'propertyName'=>'propertyValue',
			),
		);
	}

	public function actions()
	{
		// return external action classes, e.g.:
		return array(
			'action1'=>'path.to.ActionClass',
			'action2'=>array(
				'class'=>'path.to.AnotherActionClass',
				'propertyName'=>'propertyValue',
			),
		);
	}
	*/
}