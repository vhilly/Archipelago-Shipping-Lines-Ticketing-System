<?php

class VcardController extends WebBaseController
{
	public function allowedActions()
	{
		return 'index,view';
	}

	public function init(){
		parent::init();
	}

	/**
	* Configure Controller Actions
	* Action class are stored in `ext.actions`.
	*/
	public function actions(){
		return array(
			"index"	=>	array(
				"class"	=>	"ext.actions.BrowseAction",
			),
			"report"	=>	array(
				"class"	=>	"ext.actions.BrowseAction",
				"defaultView"	=>	"excelIndex",
			),
			"view"	=>	array(
				"class"	=>	"ext.actions.ViewAction",
			),
			"export"	=>	array(
				"class"	=>	"ext.actions.BrowseAction",
				"defaultView"	=>	"printView",
			),
			"create"	=>	array(
				"class"	=>	"ext.actions.CreateAction",
			),
			"update"	=>	array(
				"class"	=>	"ext.actions.UpdateAction",
			),
			"delete"	=>	array(
				"class"	=>	"ext.actions.DeleteAction",
			),
			"admin"	=>	array(
				"class"	=>	"ext.actions.AdminAction",
			),
			"settings"	=>	array(
				"class"	=>	"ext.actions.SettingsAction",
			),
		);
	}
	/**
	 * Import a vcard file
	 */
	function actionImport() {
		$data = array('errors' => '');
		$file = CUploadedFile::getInstanceByName('datafile');
		$file = 1;
		if (! is_null($file)){
			/*
			$data['errors'] = $file->getError();
			$dest = Yii::getPathOfAlias("webroot.files") . DIRECTORY_SEPARATOR . $file->getName();
			$file->saveAs($dest);
			*/
			$dest = Yii::getPathOfAlias('ext.vendors.PEAR.tests') . DIRECTORY_SEPARATOR . 'sample.vcf';
			Yii::import('ext.vendors.PEAR.*');
			require_once 'File/IMC.php';
			$parse = File_IMC::parse('vCard'); // new parser
    		$info = $parse->fromFile($dest);
    		var_dump($info);
    		$vcard = File_IMC::build('vCard'); // new builder
    		//$vcard->setFromArray($info);
			//print $vcard->getFormattedName();
		}
		$this->render("import", $data);
	}
}
