<?php
/**
 * Portlet Generator.
 *
 * @author Stefan Volkmar <volkmar_yii@email.de>
 * @link http://www.yiiframework.com/extension/yii-generator-collection/
 * @license BSD
 */

class PortletGenerator extends CCodeGenerator
{
    public $codeModel='ext.gtc.portlet.PortletCode';
   
}
?>