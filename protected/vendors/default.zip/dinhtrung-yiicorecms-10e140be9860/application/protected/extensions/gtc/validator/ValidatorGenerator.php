<?php
/**
 * Validator Generator.
 *
 * @author Stefan Volkmar <volkmar_yii@email.de>
 * @link http://www.yiiframework.com/extension/yii-class-generator-collection/
 * @license BSD
 */
class ValidatorGenerator extends CCodeGenerator
{
    public $codeModel='ext.gtc.validator.ValidatorCode';
}
?>