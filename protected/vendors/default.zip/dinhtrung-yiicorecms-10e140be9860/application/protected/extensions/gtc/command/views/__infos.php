<p style="padding:5px;">
CConsoleCommand represents an executable user command. (<a href="http://www.yiiframework.com/doc/guide/topics.console" target="_blank">more...</a>)
</p>