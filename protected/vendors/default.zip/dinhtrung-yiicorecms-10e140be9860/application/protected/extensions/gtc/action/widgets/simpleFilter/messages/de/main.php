<?pp
/**
 * German translation of JSimpleFilter.
 *
 * @author Stefan Volkmar <volkmar_yii@email.de> 
 * @package simpleFilter.messages.de
 * @since 1.0
 * @uses YiiFramework 1.1.6
 */

return array(
    'Invalid type. Property "data" must be an array.'=>'Ungülter Datentyp. Property "data" muss ein Array sein.',    
);
?>
