<?php include(dirname(__FILE__).'/copyright.php'); ?>
class <?php echo ucfirst($this->className); ?> extends <?php echo $this->baseClass."\n"; ?>
{
	/**
	 * Renders the content of the portlet.
	 */
	protected function renderContent()
	{
	}
}