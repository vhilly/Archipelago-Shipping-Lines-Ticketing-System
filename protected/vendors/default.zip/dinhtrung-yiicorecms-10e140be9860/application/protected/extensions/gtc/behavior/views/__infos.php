<div style="padding:5px;">
This generator is for different behavior classes.<br />Derive your behavior classes from:
<ul style="margin-top:8px">
<li>CBehavior</li>
<li>CModelBehavior</li>
<li>CActiveRecordBehavior</li>
</ul>
</div>
