<?php
Yii::setPathOfAlias('ClassGenerator',dirname(__FILE__));
class ClassGenerator extends CCodeGenerator
{
    public $codeModel='ext.gtc.class.ClassCode';
}
?>
