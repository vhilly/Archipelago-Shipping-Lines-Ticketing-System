<?php
return array (
	'All'=>'Alle',
	'0-9'=>'0-9',
	'Go to letter: '=>'Buchstabe: ', 
	'There is no value set for "attribute". You must set the model attribute the pagination condition should be applied to.' => 'Es wurde kein Wert f�r "attribute" gesetzt. Es muss angegeben werden, auf welches Attribut des Models sich AlphaPagination beziehen soll.',
);